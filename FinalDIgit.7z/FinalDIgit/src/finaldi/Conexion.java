/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package finaldi;

import java.sql.*;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import tablas.Productos;

/**
 *
 * @author Dinaxty
 */
public class Conexion {
    private Connection con;
    
    public Statement sentencia;
    private ResultSet registro;
    
    private String query;
    //Datos de la conexion
    //private static final String driver="com.mysql.jc.jdbc.Driver";
    private static final String user="root";
    private static final String pass="root";
    private static final String url="jdbc:mysql://localhost:3308/tienda?serverTimezone=UTC";
    
    public Conexion(){
        con=null;
        
        try{
            //Class.forName(driver);
            con= (Connection) DriverManager.getConnection(url,user,pass);
            
            if(con!=null){
                JOptionPane.showMessageDialog(null, "Conectado con exito","Conectado",1);
            }
            sentencia = con.createStatement();
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, "Error al conectar","Error!!",2);
            System.out.println(e);
        }
    }
    public ArrayList getProductos(){
       ArrayList<Productos> lista=null;
       Productos g;
       
        try {
            registro = sentencia.executeQuery(query);
            lista=new ArrayList();
            
            while(registro.next()){
                g = new Productos();
                 g.setId(registro.getInt("ID"));
                 g.setNombre(registro.getString("nombre"));
                 g.setDescripcion(registro.getString("descripcion"));
                g.setPrecio(registro.getFloat("precio"));
                g.setStock(registro.getInt("Stock"));
                
                lista.add(g);
            }
            
            
        } catch (SQLException ex) {
            Logger.getLogger(Conexion.class.getName()).log(Level.SEVERE, null, ex);
        }
        return lista;
    }
    public ArrayList getProductosN(){
       ArrayList<Productos> lista2=null;
       Productos g2;
       
        try {
            registro = sentencia.executeQuery(query);
            lista2=new ArrayList();
            
            while(registro.next()){
                g2 = new Productos();
                 
                 g2.setNombre(registro.getString("nombre"));
                 
                 g2.setPrecio(registro.getFloat("Precio"));
                 
                 g2.setStock(registro.getInt("Stock"));
                 
                lista2.add(g2);
            }
            
            
        } catch (SQLException ex) {
            Logger.getLogger(Conexion.class.getName()).log(Level.SEVERE, null, ex);
        }
        return lista2;
    }
    public String getQuery() {
        return query;
    }

    public void setQuery(String query) {
        this.query = query;
    }
    
}
